package project3;

import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;

import javax.swing.*;
import java.awt.GridLayout;

// this class makes up the interface while handling the button
public class Interface extends JFrame implements ActionListener {

	JFrame frame = new JFrame();

	// labels
	JLabel originalListLab = new JLabel("Original List: ");
	JLabel sortedListLab = new JLabel("Sorted List: ");

	// textfields
	JTextField ogList = new JTextField(16);
	JTextField sortedList = new JTextField(16);

	// the button
	JButton sort = new JButton("Perform Sort");

	JRadioButton asc = new JRadioButton("Ascending");
	JRadioButton des = new JRadioButton("Decending");

	JRadioButton num = new JRadioButton("Integer");
	JRadioButton frac = new JRadioButton("Fraction");

	public Interface() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		ButtonGroup sortOrder = new ButtonGroup();
		ButtonGroup numericType = new ButtonGroup();

		sortOrder.add(asc);
		sortOrder.add(des);

		numericType.add(num);
		numericType.add(frac);

		frame.setLayout(getLayout());
		Panel p1 = new Panel();
		Panel p2 = new Panel();
		Panel p3 = new Panel();
		JPanel p4 = new JPanel();
		JPanel p5 = new JPanel();
		Panel p6 = new Panel();

		Panel p7 = new Panel();

		frame.setSize(300, 250);

// add the elements
		p1.add(originalListLab);
		p1.add(ogList);

		p2.add(sortedListLab);
		p2.add(sortedList);

		p3.add(sort);

		p4.setLayout(new GridLayout(2, 1));
		p4.add(asc);
		p4.add(des);
		p4.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Sort Order"));

		p5.setLayout(new GridLayout(2, 1));
		p5.add(num);
		p5.add(frac);
		p5.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Num Type"));

		p7.add(p1);
		p7.add(p2);
		p7.add(p3);
		p6.add(p4);
		p6.add(p5);
		p7.add(p6);

		frame.add(p7);

		asc.setSelected(true);
		num.setSelected(true);

		frame.setTitle("Binary sort tree");
		frame.setVisible(true);

		sort.addActionListener(this); // makes the button do something

	}

	@Override
// this method takes the text from the textfield and sends it over to be broken down into a string array seperated by spaces
	public void actionPerformed(ActionEvent event) {

		
		try {
			sortedList.setText("");
			if("".equals(ogList.getText().trim())) {
				JOptionPane.showMessageDialog(this, "why you no enter values?");
				return;
			}
			String list[] = ogList.getText().trim().split(" ");
			BST bst = new BST<>(); //breate an object for the bst
			
			
			if(num.isSelected()) {
				for (int i=0; i < list.length; i++) {
					Integer a =Integer.valueOf(list[i]);// if it is integers then add them into a bst
					bst.add(a);
				}
			}else if (frac.isSelected()) {
				for (int i =0; i < list.length; i++) {// if it is fractions then create fraction object
					bst.add(new Frac(list[i]));
				}
			}
			
			if(asc.isSelected()) {

					bst.asc(bst.root);
					sortedList.setText(bst.s);//if ascending requested then call the ascending method after values have been added into the tree
				
				}else if(des.isSelected()) {

						// method call to sort according to descending order
						bst.des(bst.root);

						sortedList.setText(bst.s);
					
			}
		}catch(Exception e){
	    	  JOptionPane.showMessageDialog(this, "wai you no enter correct values?!?"); //just an error message :-)
	    	  sortedList.setText("");
	}
}
}
