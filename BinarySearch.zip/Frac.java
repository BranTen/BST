package project3;
/*
 * this method is for fractions and compares them here
 */
public class Frac implements Comparable{

	String frac;
	Frac(String s){ // splits the fraction in order to be compared
		String num[] = s.split("/");
		if (num.length != 2) {
			throw new NumberFormatException();
		}
		frac = s;
	}
	@Override
	public int compareTo(Object o) {// this compares the two fractions so that greater or lesser one can be selected
		// TODO Auto-generated method stub
		Frac f = (Frac)o;
		String num[] = f.frac.split("/");
		Double value = Double.valueOf(num[0])/Double.valueOf(num[1]);
		num = frac.split("/");
		Double value2 = Double.valueOf(num[0])/Double.valueOf(num[1]);
		return value2.compareTo(value);
	}

	
}
