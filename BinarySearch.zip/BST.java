package project3;
/*
 * this method is where each value gets added into the bst
 */
public class BST <E extends Comparable<E>> {
//E is my comparable value
	Node root;
	String s = "";
	public class Node { // less complicated to hae the node class withen the bst
		Node l, r; // standard left and right nodes
		E val;

		Node(E val){
			this.val = val;
		}
		}

	public boolean isEmpty() { // this method is for the first node to create a root
		if(root == null) {
			return true;
		}
		return false;
	}
	
	public void add(E val) { // this creates the root node if there is not one already if not it gets redirected
		if(isEmpty() == true) {
			root = new Node (val);
		}else {
			add(root, val);
		}
	}
	private void add(Node n, E val) { // this method is the real meat of the program
		// TODO Auto-generated method stub
		if(val.compareTo(n.val) < 0) {// this is where the comparison between nodes 
			if(n.l == null){
				n.l = new Node(val); // if desired node is empty write it in 
			}else {
				add(n.l,val); // if not then keep traversing
			}
		}
		if(val.compareTo(n.val) >=0) {// for right hand comparison we ned to rememebr to use the right node
			if(n.r == null){
				n.r = new Node(val);
			}else {
				add(n.r,val);
			}
		}
		
	}
	
	public void asc(Node n) { // this method gets the ascending notation in the correct order
		if(n != null) {
			asc(n.l); 
			s +=n.val + " "; // adds to the string to keep them all in one place 
			asc(n.r);
		}
	}
	public void des(Node n) { // this method gets the values in descending order
		if(n != null) {
			des(n.r);
			s +=n.val + " ";
			des(n.l);// recursion in order to get all values in the tree
		}
	}	
}
