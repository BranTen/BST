package project3;

public class Launcher {

	public static void main(String[] args) {
		// main program launches the gui interface 
		Interface i = new Interface();
	}

}
